﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TZ.ImportDesk.Modal
{
    public class Client
    {
      //clientKeyPassword ="clientid123*"
     //ClientDataProviderPassword="talentozbiometric123*"

        public string ClientKey { get; set; }
        public string ClientName { get; set; }
        public string ClientDataProvider { get; set; }
    }
}
